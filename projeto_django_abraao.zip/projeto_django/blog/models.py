from django.db import models

class Ufs(models.model):
    id_uf = models.AutoField(primary.key = True)
    nome_uf = models.CharField(max_length=30)
    sigla_uf = models.CharField(max_length=2)

class Cidades(models.Model):
    id_cidade = models.AutoField(primary.key = True)
    nome_cidade = models.CharField(max_length=50)
    id_uf = models.ForeignKey(Ufs, on_delete = models.CASCADE)

class Enderecos(models.Model):
    id_endereco = models.AutoField(primary.key = True)
    id_cidade = models.ForeignKey(Cidades, on_delete = models.CASCADE)
    logradouro = models.CharField(max_length=150)
    numero = models.CharField(max_length=8)
    cep = models.CharField(max_length=10)
    bairro = models.CharField(max_length=80)
    complemento = models.CharField(null=True, blank=True, max_length = 60)
    observacoes = models.CharField()


class

class

class


